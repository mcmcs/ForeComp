
#' Visualizes the size distortion maximum power loss tradeoff from the Diebold-Mariano test for equal predictive accuracy
#'
#' @description `Plot_Tradeoff` creates a plot to show sensitivity of statistical significance to the choice of bandwidth and how size distortion and maximum power loss vary.
#' It is designed for the Diebold-Mariano test for equal predictive accuracy (Diebold and Mariano, 1995).
#' For a size-power tradeoff plot, see Lazarus, Lewis, Stock, and Watson (2018) and Lazarus, Lewis, and Stock (2021).
#'
#' @param data A data frame.
#' @param f1 Column containing forecaster 1's predictions. Should be a string.
#' @param f2 Column containing forecaster 2's predictions. Should be a string.
#' @param y Column containing the realized value for the outcome variable. Should be a string.
#' @param loss_function The transformation applied to the forecast error. Defaults to squared error loss. The user supplied function should take two inputs and a scalar output, loss = loss_function(f, y). For example, quadratic loss function would be defined as \code{loss_function=function(f,y){(f-y)^2}}.
#' @param n_sim The number of simulations used to generate the ARIMA model. Defaults to 1,000.
#' @param m_set The truncation parameter. If \code{NULL}, the function constructs a default grid centered around the package default bandwidth for \code{dm.test.bt.fb},
#' \eqn{M_0 = \lceil 1.3\sqrt{T}\rceil} (LLSW), where \eqn{T} is the effective sample size after applying \code{na_handling}. It should be a vector of integers with the values of \eqn{M} you would like to plot.
#' @param cl Significance level used in the hypothesis test. Defaults to 0.05. Only 0.05 and 0.10 are currently supported because the fixed-b approximation is implemented for these levels.
#' @param verbose TRUE to print out the progress to the console. Defaults to TRUE.
#' @param no_m_label TRUE to plot without m labels. Defaults to FALSE.
#' @param na_handling How to handle missing/non-finite loss differentials. \code{"zero"} (default) replaces them with 0 (Application 2 convention), \code{"drop"} removes them (Application 1 convention), and \code{"error"} stops if any are present.
#' @returns A list of length 2. The first element is a ggplot2 object of the size-power tradeoff. The second element is the underlying data used to construct the plot in element 1.
#' @author Nathan Schor and Minchul Shin
#' @importFrom forecast auto.arima
#' @importFrom stats acf
#' @importFrom stats pnorm
#' @importFrom stats approx
#' @importFrom stats arima.sim
#' @importFrom stats quantile
#' @importFrom stats rnorm
#' @importFrom astsa arma.spec
#' @importFrom rlang .data
#' @import ggplot2
#' @export
#' @references Diebold, F. X. & Mariano, R. S. (1995), Comparing Predictive Accuracy, \emph{Journal of Business & Economic Statistics}, \bold{13}(3), 253-263.
#' @references Lazarus, E., Lewis, D. J., Stock, J. H. & Watson, M. W. (2018), HAR Inference: Recommendations for Practice, \emph{Journal of Business & Economic Statistics}, \bold{36}(4), 541-559.
#' @references Lazarus, E., Lewis, D. J. & Stock, J. H. (2021), The Size-Power Tradeoff in HAR Inference, \emph{Econometrica}, \bold{89}(5), 2497-2516.
#' @examples
#' \donttest{
#' # A typical example
#' set.seed(1234)
#' output = Plot_Tradeoff(
#'   data = TBILL,
#'   f1   = "SPFfor_Step1",
#'   f2   = "NCfor_Step1",
#'   y    = "Realiz1",
#'   m_set = seq(from = 1, to = 70, by = 10)
#' )
#' output[[1]] # The first element is a ggplot2 object of the size-power tradeoff.
#' output[[2]] # The second element is the underlying data used to construct the plot in element 1.
#'
#' # An example with a user supplied loss function
#' # To use the mean absolute error as a loss function rather than a quadratic loss function
#' set.seed(1234)
#' output = Plot_Tradeoff(
#'   data = TBILL,
#'   f1   = "SPFfor_Step1",
#'   f2   = "NCfor_Step1",
#'   y    = "Realiz1",
#'   loss_function = function(f,y){ abs(f-y) },
#'   m_set = seq(from = 1, to = 50, by = 10)
#' )
#'
#' # An example without (f1, f2, y). The function will take the first three columns and use them
#' set.seed(1234)
#' tmpdata = TBILL[, c("SPFfor_Step1", "NCfor_Step1", "Realiz1")] # data with [f1, f2, y]
#' Plot_Tradeoff(
#'   data = tmpdata,
#'   m_set = seq(from = 1, to = 50, by = 10)
#' )
#' }
#'



Plot_Tradeoff <- function(data,
                          f1 = NULL,
                          f2 = NULL,
                          y  = NULL,
                          loss_function = NULL,
                          n_sim = 1000,
                          m_set = NULL,
                          cl = 0.05,
                          verbose = TRUE,
                          no_m_label = FALSE,
                          na_handling = c("zero", "drop", "error")) {

  # Handling options

  # Data
  if (is.null(f1)& is.null(f2) & is.null(y)){
    f1 = data[[1]];
    f2 = data[[2]];
    y  = data[[3]];
  } else if (!is.null(f1) & !is.null(f2) & !is.null(y)) {
    f1 <- data[[f1]]
    f2 <- data[[f2]]
    y <- data[[y]]
  } else {
    stop("f1, f2, y have to be supplied altogether.")
  }

  # If the user does not supply a loss_function, we use a quadratic loss
  if (is.null(loss_function)) {
    loss_function = function(f, y){ return( (f-y)^2 ); };
  }

  na_handling = match.arg(na_handling)

  # calculating loss
  loss1 = loss_function(f1, y);
  loss2 = loss_function(f2, y);
  d     = loss1 - loss2;
  bad = !is.finite(d)
  n_bad = sum(bad)

  if (na_handling == "zero") {
    d[bad] = 0
  } else if (na_handling == "drop") {
    d = d[!bad]
  } else if (n_bad > 0) {
    stop(paste0("Plot_Tradeoff encountered ", n_bad,
                " missing/non-finite values in the loss differential. ",
                "Use na_handling = \"zero\" or na_handling = \"drop\"."))
  }

  series_length = length(d)
  m_max = series_length - 1

  if (m_max < 1) {
    stop(paste0("Effective sample size after applying na_handling = \"",
                na_handling, "\" is ", series_length,
                ". At least 2 observations are required."))
  }

  # Package default bandwidth for dm.test.bt.fb (LLSW, Mopt = 1):
  #   M = ceiling(1.3 * sqrt(T)), where T is effective sample size
  m_default = min(ceiling(1.3 * sqrt(series_length)), m_max)
  m_upper   = min(max(1, round(series_length / 2)), m_max)

  # mset - default value
  if (is.null(m_set)) {
    # Dense region: every integer in [m_default-7, m_default+7]
    dense_low = max(1, m_default - 7)
    dense_high = min(m_default + 7, m_upper)
    if (dense_low <= dense_high) {
      m_dense = seq(dense_low, dense_high)
    } else {
      m_dense = integer(0)
    }

    # Sparse lower tail: 3 equally spaced points from 1 to (m_default-8)
    lower_end = m_default - 8
    if (lower_end >= 1) {
      m_lower = unique(round(seq(1, lower_end, length.out = 3)))
    } else {
      m_lower = integer(0)
    }

    # Sparse upper tail: 3 equally spaced points from (m_default+8) to round(T/2)
    upper_start = m_default + 8
    if (upper_start < m_upper) {
      m_upper_pts = unique(round(seq(upper_start, m_upper, length.out = 3)))
    } else {
      m_upper_pts = integer(0)
    }

    m_set = sort(unique(c(m_lower, m_dense, m_upper_pts)))
  } else {
    if (!is.numeric(m_set) || any(!is.finite(m_set)) ||
        any(m_set %% 1 != 0) || any(m_set < 1)) {
      stop("Argument 'm_set' should be a vector of positive integers.")
    }
    m_set = sort(unique(as.integer(m_set)))
  }

  # Always include the optimal M in m_set
  if (!(m_default %in% m_set)) {
    m_set = sort(unique(c(m_set, m_default)))
  }

  if (max(m_set) > m_max) {
    stop(paste0("Argument 'm_set' should satisfy max(m_set) <= ", m_max,
                " after NA handling (effective sample size T = ",
                series_length, ")."))
  }

  if (!is.logical(no_m_label)) {stop("Argument 'no_m_label' should be either TRUE or FALSE.")}
  if (!is.numeric(n_sim) | n_sim %% 1 != 0 | n_sim <= 0) {stop("Argument 'n_sim' should be a natural number.")}
  if (!is.numeric(cl) | length(cl) != 1 | is.na(cl) | cl <= 0 | cl >= 1) {stop("Argument 'cl' should be a scalar between 0 and 1.")}
  if (!(cl %in% c(0.05, 0.10))) {stop("Argument 'cl' should be 0.05 or 0.10 because fixed-b critical values are implemented only for these levels.")}


  # other info
  conf_level <- cl
  m_set_length <- length(m_set)

  # matrix to store
  mat_size_distortion_dm <- matrix(NA, m_set_length, 1)
  mat_power_loss_dm <- matrix(NA, m_set_length, 1)

  mat_size_distortion_b <- matrix(NA, m_set_length, 1)
  mat_power_loss_b <- matrix(NA, m_set_length, 1)

  mat_size_distortion_d <- matrix(NA, m_set_length, 1)
  mat_power_loss_d <- matrix(NA, m_set_length, 1)

  mut <- mean(d); # demean
  dt_tilde <- d - mut


  # --- Estimate ARIMA and extract information
  a = forecast::auto.arima(y=dt_tilde, max.p = 12, max.q=12, stationary=T, ic="aic", seasonal=F, allowmean=F);
  i_ar = grep("ar", names(a$coef));
  i_ma = grep("ma", names(a$coef));
  m_sim = list("ar"=a$coef[i_ar], "ma"=a$coef[i_ma]);

  if (length(m_sim$ar)==0){m_sim$ar=0.0}
  if (length(m_sim$ma)==0){m_sim$ma=0.0}

  # --- Generate data for size and power computation (this loop alos pre-computes long-run variance)
  Mmax = min(c(series_length-1,200)); # maximum possible M considered in this experimen
  mat_dt   = matrix(NA, series_length, n_sim); # matrix that stores data (for size calculation)
  mat_dtm  = matrix(NA, 1, n_sim);    # matrix that stores mean of data
  mat_acf  = matrix(NA, (Mmax+1), n_sim); # matrix that stores acf
  for (irep in 1:n_sim){

    # data
    dt_sim = arima.sim(m_sim, n=series_length, innov = rnorm(series_length, 0, sqrt(a$sigma2)));
    mat_dt[,irep] = dt_sim;
    mat_dtm[,irep] = mean(dt_sim);
    # autocovariance matrix
    d.cov = stats::acf(dt_sim, lag.max = (Mmax), type="covariance", plot=FALSE, demean=TRUE)$acf[,,1];
    mat_acf[,irep] = d.cov;
  }


  # --- Setting for trade-off figure
  del_grid = seq(from=0, to=10, by=0.25);
  ndel = length(del_grid);

  v_M <- vector(mode = "integer", length = m_set_length)
  v_hypothesis_test_b <- vector(mode = "logical", length = m_set_length)
  v_test_statistic_b <- vector(mode = "logical", length = m_set_length)
  v_hypothesis_test_dm <- vector(mode = "logical", length = m_set_length)
  v_test_statistic_dm <- vector(mode = "logical", length = m_set_length)

  # --- Loop over M set
  for (iM in 1:m_set_length){

    Mchoice = m_set[iM]; #our choice of M for this iteration

    testres_b  = dm.test.bt.fb(d, cl = conf_level, M = Mchoice);
    wce_b_rej  = testres_b$rej
    wce_b_stat = testres_b$stat

    testres_dm  = dm.test.bt(d, cl = conf_level, M = Mchoice);
    wce_dm_rej  = testres_dm$rej  # CHANGE
    wce_dm_stat = testres_dm$stat # CHANGE

    v_M[iM] <- Mchoice
    v_hypothesis_test_b[iM] <- wce_b_rej
    v_test_statistic_b[iM] <- wce_b_stat
    v_hypothesis_test_dm[iM] <- wce_dm_rej
    v_test_statistic_dm[iM] <- wce_dm_stat

    # --- Oracle ---

    # --- Power for oracle

    # long-run variance
    ss = astsa::arma.spec(ar = m_sim$ar, ma = m_sim$ma, var.noise = a$sigma2, n.freq = 100, plot = FALSE);
    Om = ss$spec[1]; #this is 2*pi*f(0), spectrum at zero rather than a spectral density at zero

    # --- Standard test


    # --- Size computation for DM-WCE-dm, DM-WCE-b, DM-WPE-d
    M = Mchoice;
    mat_stat =    matrix(NA, n_sim, 1);
    mat_d.var   = matrix(NA, n_sim, 1);
    mat_rej_dm  = matrix(NA, n_sim, 1);
    mat_rej_b   = matrix(NA, n_sim, 1);
    for (irep in 1:n_sim){
      d.cov  = mat_acf[1:(M+1),irep];
      d.var  = ( d.cov[1] + 2*sum( (1 - ((1:M)/M) ) * d.cov[-1] ) ) / series_length;

      # Traditional NW, DM (DM-WCE-dm)
      dmstat = mean(mat_dtm[,irep]) / sqrt(d.var);
      pval   = 2 * stats::pnorm(-abs(dmstat), mean=0, sd=1); #p-val based on normal approximation
      rej_dm    = pval < conf_level; #reject decision

      # Fixed-b NW (DM-WCE-b)
      b = M / series_length;
      if (conf_level == 0.05){
        crit = 1.9600 + 2.9694*b + 0.4160*b^2 -0.5324*b^3; #0.975 quantile
      } else if (conf_level == 0.10){
        crit = 1.6449 + 2.1859*b + 0.3142*b^2 -0.3427*b^3; #0.950 quantile
      }
      # rejection decision
      rej_b = abs(dmstat) > crit; #reject decision


      # ***Minchul DM-WPE-d
      # do be done


      # store results
      mat_stat[irep,] = dmstat;
      mat_d.var[irep,] = d.var;
      mat_rej_dm[irep, ] = rej_dm;
      mat_rej_b[irep, ] = rej_b;
    }
    size_distortion_dm = mean(mat_rej_dm) - conf_level;
    size_distortion_b = mean(mat_rej_b) - conf_level;


    # --- Power of a standard test (DM-NW)
    # Note that WCE-DM and WCE-B have the same power property when size-corrected
    # --- size-corrected crit val
    c05_star = quantile(abs(mat_stat), (1-conf_level));

    # --- size-corrected power
    mat_stat = matrix(NA, n_sim, ndel);
    mat_rej  = matrix(NA, n_sim, ndel);
    mat_rej2 = matrix(NA, n_sim, ndel);
    for (irep in 1:n_sim){

      m_i = mat_dtm[,irep];
      s_i = sqrt(mat_d.var[irep,]);

      for (idel in 1:ndel){

        # DM test with NW
        dmstat = (m_i + (1/sqrt(series_length)) *sqrt(Om)*del_grid[idel]) / s_i; #statistic
        pval = 2 * stats::pnorm(-abs(dmstat), mean=0, sd=1); #p-val based on normal approximation
        rej = pval < conf_level; #reject decision

        mat_rej[irep, idel] = rej; #for raw power
        mat_stat[irep, idel] = dmstat;
        mat_rej2[irep, idel] = abs(dmstat) > c05_star; # for size-corrected power
      }
    }


    #======================================

    # --- another Oracle ---
    grid = seq(from=0, to=5, by=0.05);
    samp = del_grid;
    z_crit = stats::qnorm(1 - conf_level / 2)
    pow_gau = stats::pnorm(-z_crit+grid) + stats::pnorm(-z_crit-grid);

    # --- Maximum power loss
    powinterp = stats::approx(samp, apply(mat_rej2, 2, mean), grid)$y; #interpolated power
    max_power_loss_dm = max(pow_gau-powinterp);
    max_power_loss_b = max_power_loss_dm; #WCE-DM and WCE-B have the same power property

    # --- Collect results
    if (verbose) {
      print(paste0("M = ", iM, " / ", m_set_length));
    }
    mat_size_distortion_dm[iM] = size_distortion_dm;
    mat_power_loss_dm[iM] = max_power_loss_dm;

    mat_size_distortion_b[iM] = size_distortion_b;
    mat_power_loss_b[iM] = max_power_loss_b;

  } #end of iM iteration

  df_hypoth_testing <- data.frame(
    v_M,
    v_hypothesis_test_b,
    v_test_statistic_b,
    v_hypothesis_test_dm,
    v_test_statistic_dm
  )

  df_size_power <- data.frame(
    M = m_set,
    b_size_distortion = mat_size_distortion_b[,1],
    b_power_loss = mat_power_loss_b[,1]
  )

  plotting_data <- merge(df_size_power, df_hypoth_testing, by.x = "M", by.y = "v_M")
  plotting_data["v_hypothesis_test_b"] <- ifelse(v_hypothesis_test_b == TRUE, "cross", "circle")


  # Subset for the LLSW default M
  default_data <- plotting_data[plotting_data$M == m_default, , drop = FALSE]

  plot <- ggplot(plotting_data, aes(x = .data$b_size_distortion, y = .data$b_power_loss)) +
    geom_path(linewidth = 1, linetype = "dashed") +
    geom_point(aes(shape = v_hypothesis_test_b), size = 4.5, color = "red", stroke = 1.5) +
    geom_point(data = default_data, aes(shape = v_hypothesis_test_b),
               size = 7, color = "green4", stroke = 2.5, show.legend = FALSE) +
    labs(
      x = "Size Distortion",
      y = "Maximum Power Loss"
    ) +
    theme_minimal(base_size = 16) +
    theme(legend.position = "bottom", legend.title = element_blank(),
          legend.text = element_text(size = 14),
          axis.title = element_text(size = 16),
          axis.text = element_text(size = 14)) +
    scale_shape_manual(values=c(16, 4), labels = c("H0 not rejected", "H0 rejected"))

  # add m_set annotation
  if (no_m_label == FALSE){
    plot <- plot + geom_text(aes(label = M), nudge_x = .003, nudge_y = .007, size = 5)
  }

  print(plot)
  return(invisible(list(plot, plotting_data)))
}
