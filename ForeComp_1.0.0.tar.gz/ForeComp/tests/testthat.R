library(testthat)
library(ForeComp)

test_check("ForeComp")
